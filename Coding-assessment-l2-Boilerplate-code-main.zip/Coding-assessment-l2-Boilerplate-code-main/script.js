console.log('====================================');
console.log("Connected");
console.log('====================================');


document.getElementById('add-to-cart').addEventListener('click', function() {
    alert('Item added to cart!');
    function selectCategory(category) {
        console.log("Selected category: " + category);